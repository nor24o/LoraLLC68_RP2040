#ifndef SIMPLE_LPP_HPP
#define SIMPLE_LPP_HPP

#include <Arduino.h>

// --- Data Type Definitions ---
// Format: [ID][TYPE][VAL_HIGH][VAL_LOW]
#define TYPE_TEMP       0x01  // Temperature (x100)
#define TYPE_HUMIDITY   0x02  // Humidity (x2)
#define TYPE_VOLTAGE    0x03  // Voltage (x100)
#define TYPE_PRESSURE   0x04  // Pressure (x10)
#define TYPE_DIGITAL    0x00  // Digital (x1)
#define TYPE_STATUS     0x50  // Custom type for your Status Bitmask (1 Byte, x1)

class SimpleLPP {
public:
    // Constructor
    SimpleLPP(uint8_t size) {
        _maxSize = size;
        _buffer = (uint8_t*) malloc(size);
        _cursor = 0;
    }

    // Destructor
    ~SimpleLPP() {
        if (_buffer) free(_buffer);
    }

    // Reset buffer to start a new packet
    void reset() {
        _cursor = 0;
    }

    // Getters for LoRa transmission
    uint8_t* getBuffer() {
        return _buffer;
    }

    uint8_t getSize() {
        return _cursor;
    }

    // --- Core Adder Function ---
    // Returns true if added, false if buffer full
    bool addGeneric(uint8_t id, uint8_t type, int16_t value) {
        if ((_cursor + 4) > _maxSize) {
            return false; // Buffer overflow protection
        }

        _buffer[_cursor++] = id;                 // Byte 1: Sensor ID
        _buffer[_cursor++] = type;               // Byte 2: Type
        _buffer[_cursor++] = (value >> 8) & 0xFF;// Byte 3: High Byte
        _buffer[_cursor++] = value & 0xFF;       // Byte 4: Low Byte
        
        return true;
    }

    // --- Type Specific Wrappers ---

    bool addTemperature(uint8_t id, float celsius) {
        int16_t val = (int16_t)(celsius * 100);
        return addGeneric(id, TYPE_TEMP, val);
    }

    bool addHumidity(uint8_t id, float percent) {
        int16_t val = (int16_t)(percent * 2);
        return addGeneric(id, TYPE_HUMIDITY, val);
    }

    bool addVoltage(uint8_t id, float volts) {
        int16_t val = (int16_t)(volts * 100);
        return addGeneric(id, TYPE_VOLTAGE, val);
    }

    bool addDigital(uint8_t id, uint8_t value) {
        return addGeneric(id, TYPE_DIGITAL, (int16_t)value);
    }
    // Add the status byte (flags)
    bool addStatus(uint8_t id, uint8_t statusByte) {
        return addGeneric(id, TYPE_STATUS, (int16_t)statusByte);
    }

private:
    uint8_t* _buffer;
    uint8_t _maxSize;
    uint8_t _cursor;
};

#endif